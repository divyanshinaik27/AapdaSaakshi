from django.apps import AppConfig


class DisastersConfig(AppConfig):
    name = 'disasters'
