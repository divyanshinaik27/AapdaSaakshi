# disaster-management
disaster management system that predict disasters , we want to enter call for code IBM compition by this project
